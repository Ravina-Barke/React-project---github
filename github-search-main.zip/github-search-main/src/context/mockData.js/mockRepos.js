export default [
  {
    id: 239164394,
    node_id: "MDEwOlJlcG9zaXRvcnkyMzkxNjQzOTQ=",
    name: "bazinga-example",
    full_name: "john-smilga/bazinga-example",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/bazinga-example",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/bazinga-example",
    forks_url: "https://api.github.com/repos/john-smilga/bazinga-example/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/bazinga-example/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/bazinga-example/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/bazinga-example/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/bazinga-example/deployments",
    created_at: "2020-02-08T16:30:10Z",
    updated_at: "2020-05-12T15:57:33Z",
    pushed_at: "2020-02-08T16:30:48Z",
    git_url: "git://github.com/john-smilga/bazinga-example.git",
    ssh_url: "git@github.com:john-smilga/bazinga-example.git",
    clone_url: "https://github.com/john-smilga/bazinga-example.git",
    svn_url: "https://github.com/john-smilga/bazinga-example",
    homepage: null,
    size: 173,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 154058683,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTQwNTg2ODM=",
    name: "boot-sweets-setup",
    full_name: "john-smilga/boot-sweets-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/boot-sweets-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/boot-sweets-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/boot-sweets-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/boot-sweets-setup/deployments",
    created_at: "2018-10-21T22:39:19Z",
    updated_at: "2020-02-04T17:11:04Z",
    pushed_at: "2018-10-21T22:39:44Z",
    git_url: "git://github.com/john-smilga/boot-sweets-setup.git",
    ssh_url: "git@github.com:john-smilga/boot-sweets-setup.git",
    clone_url: "https://github.com/john-smilga/boot-sweets-setup.git",
    svn_url: "https://github.com/john-smilga/boot-sweets-setup",
    homepage: null,
    size: 2258,
    stargazers_count: 5,
    watchers_count: 5,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 12,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 12,
    open_issues: 0,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 225279403,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjUyNzk0MDM=",
    name: "bootstrap-car-dealership",
    full_name: "john-smilga/bootstrap-car-dealership",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/bootstrap-car-dealership",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/bootstrap-car-dealership",
    forks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-car-dealership/deployments",
    created_at: "2019-12-02T03:42:37Z",
    updated_at: "2020-06-10T17:40:10Z",
    pushed_at: "2019-12-02T03:42:54Z",
    git_url: "git://github.com/john-smilga/bootstrap-car-dealership.git",
    ssh_url: "git@github.com:john-smilga/bootstrap-car-dealership.git",
    clone_url: "https://github.com/john-smilga/bootstrap-car-dealership.git",
    svn_url: "https://github.com/john-smilga/bootstrap-car-dealership",
    homepage: null,
    size: 7379,
    stargazers_count: 2,
    watchers_count: 2,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 161136700,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjExMzY3MDA=",
    name: "bootstrap-furniture-e-commrece",
    full_name: "john-smilga/bootstrap-furniture-e-commrece",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/bootstrap-furniture-e-commrece",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece",
    forks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-furniture-e-commrece/deployments",
    created_at: "2018-12-10T07:44:30Z",
    updated_at: "2019-10-11T18:18:31Z",
    pushed_at: "2018-12-10T07:45:08Z",
    git_url: "git://github.com/john-smilga/bootstrap-furniture-e-commrece.git",
    ssh_url: "git@github.com:john-smilga/bootstrap-furniture-e-commrece.git",
    clone_url:
      "https://github.com/john-smilga/bootstrap-furniture-e-commrece.git",
    svn_url: "https://github.com/john-smilga/bootstrap-furniture-e-commrece",
    homepage: null,
    size: 3544,
    stargazers_count: 2,
    watchers_count: 2,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 166690253,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjY2OTAyNTM=",
    name: "bootstrap-only-bootstrap-project",
    full_name: "john-smilga/bootstrap-only-bootstrap-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/bootstrap-only-bootstrap-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-only-bootstrap-project/deployments",
    created_at: "2019-01-20T17:40:24Z",
    updated_at: "2019-10-11T18:17:23Z",
    pushed_at: "2019-01-20T17:45:13Z",
    git_url:
      "git://github.com/john-smilga/bootstrap-only-bootstrap-project.git",
    ssh_url: "git@github.com:john-smilga/bootstrap-only-bootstrap-project.git",
    clone_url:
      "https://github.com/john-smilga/bootstrap-only-bootstrap-project.git",
    svn_url: "https://github.com/john-smilga/bootstrap-only-bootstrap-project",
    homepage: null,
    size: 1799,
    stargazers_count: 2,
    watchers_count: 2,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 161137201,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjExMzcyMDE=",
    name: "bootstrap-renters-real-estate-project",
    full_name: "john-smilga/bootstrap-renters-real-estate-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/bootstrap-renters-real-estate-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/bootstrap-renters-real-estate-project/deployments",
    created_at: "2018-12-10T07:48:38Z",
    updated_at: "2020-06-10T17:41:03Z",
    pushed_at: "2018-12-10T07:49:06Z",
    git_url:
      "git://github.com/john-smilga/bootstrap-renters-real-estate-project.git",
    ssh_url:
      "git@github.com:john-smilga/bootstrap-renters-real-estate-project.git",
    clone_url:
      "https://github.com/john-smilga/bootstrap-renters-real-estate-project.git",
    svn_url:
      "https://github.com/john-smilga/bootstrap-renters-real-estate-project",
    homepage: null,
    size: 1942,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 151336838,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTEzMzY4Mzg=",
    name: "cars",
    full_name: "john-smilga/cars",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/cars",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/cars",
    forks_url: "https://api.github.com/repos/john-smilga/cars/forks",
    keys_url: "https://api.github.com/repos/john-smilga/cars/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/cars/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/cars/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/cars/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/cars/issues/events{/number}",
    events_url: "https://api.github.com/repos/john-smilga/cars/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/cars/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/cars/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/cars/tags",
    blobs_url: "https://api.github.com/repos/john-smilga/cars/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/cars/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/cars/git/refs{/sha}",
    trees_url: "https://api.github.com/repos/john-smilga/cars/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/cars/statuses/{sha}",
    languages_url: "https://api.github.com/repos/john-smilga/cars/languages",
    stargazers_url: "https://api.github.com/repos/john-smilga/cars/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/cars/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/cars/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/cars/subscription",
    commits_url: "https://api.github.com/repos/john-smilga/cars/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/cars/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/cars/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/cars/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/cars/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/cars/compare/{base}...{head}",
    merges_url: "https://api.github.com/repos/john-smilga/cars/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/cars/{archive_format}{/ref}",
    downloads_url: "https://api.github.com/repos/john-smilga/cars/downloads",
    issues_url: "https://api.github.com/repos/john-smilga/cars/issues{/number}",
    pulls_url: "https://api.github.com/repos/john-smilga/cars/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/cars/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/cars/notifications{?since,all,participating}",
    labels_url: "https://api.github.com/repos/john-smilga/cars/labels{/name}",
    releases_url: "https://api.github.com/repos/john-smilga/cars/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/cars/deployments",
    created_at: "2018-10-02T23:26:50Z",
    updated_at: "2019-10-11T18:19:05Z",
    pushed_at: "2018-10-02T23:27:32Z",
    git_url: "git://github.com/john-smilga/cars.git",
    ssh_url: "git@github.com:john-smilga/cars.git",
    clone_url: "https://github.com/john-smilga/cars.git",
    svn_url: "https://github.com/john-smilga/cars",
    homepage: null,
    size: 948,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 233153196,
    node_id: "MDEwOlJlcG9zaXRvcnkyMzMxNTMxOTY=",
    name: "css-grid-udemy-restaurant-project",
    full_name: "john-smilga/css-grid-udemy-restaurant-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/css-grid-udemy-restaurant-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/css-grid-udemy-restaurant-project/deployments",
    created_at: "2020-01-11T00:29:34Z",
    updated_at: "2020-06-10T17:40:04Z",
    pushed_at: "2020-01-15T21:40:54Z",
    git_url:
      "git://github.com/john-smilga/css-grid-udemy-restaurant-project.git",
    ssh_url: "git@github.com:john-smilga/css-grid-udemy-restaurant-project.git",
    clone_url:
      "https://github.com/john-smilga/css-grid-udemy-restaurant-project.git",
    svn_url: "https://github.com/john-smilga/css-grid-udemy-restaurant-project",
    homepage: null,
    size: 10238,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 179416940,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzk0MTY5NDA=",
    name: "Drum-Machine-Challenge",
    full_name: "john-smilga/Drum-Machine-Challenge",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/Drum-Machine-Challenge",
    description: null,
    fork: true,
    url: "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge",
    forks_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/Drum-Machine-Challenge/deployments",
    created_at: "2019-04-04T03:46:07Z",
    updated_at: "2019-10-11T18:17:13Z",
    pushed_at: "2019-02-15T18:04:03Z",
    git_url: "git://github.com/john-smilga/Drum-Machine-Challenge.git",
    ssh_url: "git@github.com:john-smilga/Drum-Machine-Challenge.git",
    clone_url: "https://github.com/john-smilga/Drum-Machine-Challenge.git",
    svn_url: "https://github.com/john-smilga/Drum-Machine-Challenge",
    homepage: null,
    size: 2933,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: false,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 224077333,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjQwNzczMzM=",
    name: "express-portfolio-server",
    full_name: "john-smilga/express-portfolio-server",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/express-portfolio-server",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/express-portfolio-server",
    forks_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/express-portfolio-server/deployments",
    created_at: "2019-11-26T01:40:21Z",
    updated_at: "2020-06-08T04:53:39Z",
    pushed_at: "2020-06-08T04:53:37Z",
    git_url: "git://github.com/john-smilga/express-portfolio-server.git",
    ssh_url: "git@github.com:john-smilga/express-portfolio-server.git",
    clone_url: "https://github.com/john-smilga/express-portfolio-server.git",
    svn_url: "https://github.com/john-smilga/express-portfolio-server",
    homepage: null,
    size: 12,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 224072105,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjQwNzIxMDU=",
    name: "express-simple-portfolio-server",
    full_name: "john-smilga/express-simple-portfolio-server",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/express-simple-portfolio-server",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server",
    forks_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/express-simple-portfolio-server/deployments",
    created_at: "2019-11-26T01:05:23Z",
    updated_at: "2019-12-12T21:00:06Z",
    pushed_at: "2019-11-26T01:14:52Z",
    git_url: "git://github.com/john-smilga/express-simple-portfolio-server.git",
    ssh_url: "git@github.com:john-smilga/express-simple-portfolio-server.git",
    clone_url:
      "https://github.com/john-smilga/express-simple-portfolio-server.git",
    svn_url: "https://github.com/john-smilga/express-simple-portfolio-server",
    homepage: null,
    size: 563,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 209595879,
    node_id: "MDEwOlJlcG9zaXRvcnkyMDk1OTU4Nzk=",
    name: "firebase-basic-app",
    full_name: "john-smilga/firebase-basic-app",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/firebase-basic-app",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/firebase-basic-app",
    forks_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/firebase-basic-app/deployments",
    created_at: "2019-09-19T16:05:37Z",
    updated_at: "2019-10-11T18:20:31Z",
    pushed_at: "2019-09-19T17:07:16Z",
    git_url: "git://github.com/john-smilga/firebase-basic-app.git",
    ssh_url: "git@github.com:john-smilga/firebase-basic-app.git",
    clone_url: "https://github.com/john-smilga/firebase-basic-app.git",
    svn_url: "https://github.com/john-smilga/firebase-basic-app",
    homepage: null,
    size: 169,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 210205879,
    node_id: "MDEwOlJlcG9zaXRvcnkyMTAyMDU4Nzk=",
    name: "firebase-restaurant-application",
    full_name: "john-smilga/firebase-restaurant-application",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/firebase-restaurant-application",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application",
    forks_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/firebase-restaurant-application/deployments",
    created_at: "2019-09-22T19:55:30Z",
    updated_at: "2019-10-11T18:20:28Z",
    pushed_at: "2019-09-24T20:36:44Z",
    git_url: "git://github.com/john-smilga/firebase-restaurant-application.git",
    ssh_url: "git@github.com:john-smilga/firebase-restaurant-application.git",
    clone_url:
      "https://github.com/john-smilga/firebase-restaurant-application.git",
    svn_url: "https://github.com/john-smilga/firebase-restaurant-application",
    homepage: null,
    size: 197,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 197610547,
    node_id: "MDEwOlJlcG9zaXRvcnkxOTc2MTA1NDc=",
    name: "flexbox-backroads-project",
    full_name: "john-smilga/flexbox-backroads-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/flexbox-backroads-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/flexbox-backroads-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/flexbox-backroads-project/deployments",
    created_at: "2019-07-18T15:14:01Z",
    updated_at: "2020-06-14T04:06:52Z",
    pushed_at: "2019-07-26T21:13:10Z",
    git_url: "git://github.com/john-smilga/flexbox-backroads-project.git",
    ssh_url: "git@github.com:john-smilga/flexbox-backroads-project.git",
    clone_url: "https://github.com/john-smilga/flexbox-backroads-project.git",
    svn_url: "https://github.com/john-smilga/flexbox-backroads-project",
    homepage: null,
    size: 3699,
    stargazers_count: 3,
    watchers_count: 3,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 155356283,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTUzNTYyODM=",
    name: "flexbox-car-dealership",
    full_name: "john-smilga/flexbox-car-dealership",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/flexbox-car-dealership",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/flexbox-car-dealership",
    forks_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/flexbox-car-dealership/deployments",
    created_at: "2018-10-30T09:14:22Z",
    updated_at: "2020-05-21T09:38:13Z",
    pushed_at: "2018-10-30T09:17:56Z",
    git_url: "git://github.com/john-smilga/flexbox-car-dealership.git",
    ssh_url: "git@github.com:john-smilga/flexbox-car-dealership.git",
    clone_url: "https://github.com/john-smilga/flexbox-car-dealership.git",
    svn_url: "https://github.com/john-smilga/flexbox-car-dealership",
    homepage: null,
    size: 1149,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 188733902,
    node_id: "MDEwOlJlcG9zaXRvcnkxODg3MzM5MDI=",
    name: "gatsby-backroads-project-recording",
    full_name: "john-smilga/gatsby-backroads-project-recording",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/gatsby-backroads-project-recording",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-backroads-project-recording/deployments",
    created_at: "2019-05-26T21:36:23Z",
    updated_at: "2020-04-21T15:16:45Z",
    pushed_at: "2020-04-21T15:16:41Z",
    git_url:
      "git://github.com/john-smilga/gatsby-backroads-project-recording.git",
    ssh_url:
      "git@github.com:john-smilga/gatsby-backroads-project-recording.git",
    clone_url:
      "https://github.com/john-smilga/gatsby-backroads-project-recording.git",
    svn_url:
      "https://github.com/john-smilga/gatsby-backroads-project-recording",
    homepage: null,
    size: 907,
    stargazers_count: 6,
    watchers_count: 6,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 4,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 4,
    open_issues: 0,
    watchers: 6,
    default_branch: "master",
  },
  {
    id: 158024818,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTgwMjQ4MTg=",
    name: "gatsby-bootstrap",
    full_name: "john-smilga/gatsby-bootstrap",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-bootstrap",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-bootstrap",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/gatsby-bootstrap/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-bootstrap/deployments",
    created_at: "2018-11-17T21:04:00Z",
    updated_at: "2019-10-11T18:18:54Z",
    pushed_at: "2018-11-17T21:04:23Z",
    git_url: "git://github.com/john-smilga/gatsby-bootstrap.git",
    ssh_url: "git@github.com:john-smilga/gatsby-bootstrap.git",
    clone_url: "https://github.com/john-smilga/gatsby-bootstrap.git",
    svn_url: "https://github.com/john-smilga/gatsby-bootstrap",
    homepage: null,
    size: 353,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 169362536,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjkzNjI1MzY=",
    name: "gatsby-coffee-project",
    full_name: "john-smilga/gatsby-coffee-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-coffee-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-coffee-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-coffee-project/deployments",
    created_at: "2019-02-06T06:06:00Z",
    updated_at: "2020-06-10T17:38:24Z",
    pushed_at: "2020-06-06T23:26:07Z",
    git_url: "git://github.com/john-smilga/gatsby-coffee-project.git",
    ssh_url: "git@github.com:john-smilga/gatsby-coffee-project.git",
    clone_url: "https://github.com/john-smilga/gatsby-coffee-project.git",
    svn_url: "https://github.com/john-smilga/gatsby-coffee-project",
    homepage: null,
    size: 3390,
    stargazers_count: 10,
    watchers_count: 10,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 5,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 8,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 5,
    open_issues: 8,
    watchers: 10,
    default_branch: "master",
  },
  {
    id: 238067823,
    node_id: "MDEwOlJlcG9zaXRvcnkyMzgwNjc4MjM=",
    name: "gatsby-courses",
    full_name: "john-smilga/gatsby-courses",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-courses",
    description: null,
    fork: true,
    url: "https://api.github.com/repos/john-smilga/gatsby-courses",
    forks_url: "https://api.github.com/repos/john-smilga/gatsby-courses/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/gatsby-courses/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/gatsby-courses/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/gatsby-courses/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-courses/deployments",
    created_at: "2020-02-03T21:41:58Z",
    updated_at: "2020-02-05T14:54:10Z",
    pushed_at: "2020-02-03T04:00:38Z",
    git_url: "git://github.com/john-smilga/gatsby-courses.git",
    ssh_url: "git@github.com:john-smilga/gatsby-courses.git",
    clone_url: "https://github.com/john-smilga/gatsby-courses.git",
    svn_url: "https://github.com/john-smilga/gatsby-courses",
    homepage: null,
    size: 4934,
    stargazers_count: 1,
    watchers_count: 1,
    language: null,
    has_issues: false,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 192434000,
    node_id: "MDEwOlJlcG9zaXRvcnkxOTI0MzQwMDA=",
    name: "gatsby-mdx-blog-project",
    full_name: "john-smilga/gatsby-mdx-blog-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-mdx-blog-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-project/deployments",
    created_at: "2019-06-17T23:58:40Z",
    updated_at: "2019-12-12T21:02:26Z",
    pushed_at: "2019-08-10T00:06:38Z",
    git_url: "git://github.com/john-smilga/gatsby-mdx-blog-project.git",
    ssh_url: "git@github.com:john-smilga/gatsby-mdx-blog-project.git",
    clone_url: "https://github.com/john-smilga/gatsby-mdx-blog-project.git",
    svn_url: "https://github.com/john-smilga/gatsby-mdx-blog-project",
    homepage: null,
    size: 531,
    stargazers_count: 2,
    watchers_count: 2,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 267145715,
    node_id: "MDEwOlJlcG9zaXRvcnkyNjcxNDU3MTU=",
    name: "gatsby-mdx-blog-udemy-course-second-project-starter-project",
    full_name:
      "john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project/deployments",
    created_at: "2020-05-26T20:31:59Z",
    updated_at: "2020-05-26T20:54:18Z",
    pushed_at: "2020-05-26T20:54:15Z",
    git_url:
      "git://github.com/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project.git",
    ssh_url:
      "git@github.com:john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project.git",
    clone_url:
      "https://github.com/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project.git",
    svn_url:
      "https://github.com/john-smilga/gatsby-mdx-blog-udemy-course-second-project-starter-project",
    homepage: null,
    size: 23746,
    stargazers_count: 0,
    watchers_count: 0,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 0,
    default_branch: "master",
  },
  {
    id: 222823776,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjI4MjM3NzY=",
    name: "gatsby-mdx-project-starter",
    full_name: "john-smilga/gatsby-mdx-project-starter",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-mdx-project-starter",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-mdx-project-starter/deployments",
    created_at: "2019-11-20T01:25:35Z",
    updated_at: "2019-11-20T01:26:45Z",
    pushed_at: "2019-11-20T01:26:43Z",
    git_url: "git://github.com/john-smilga/gatsby-mdx-project-starter.git",
    ssh_url: "git@github.com:john-smilga/gatsby-mdx-project-starter.git",
    clone_url: "https://github.com/john-smilga/gatsby-mdx-project-starter.git",
    svn_url: "https://github.com/john-smilga/gatsby-mdx-project-starter",
    homepage: null,
    size: 497,
    stargazers_count: 0,
    watchers_count: 0,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 0,
    default_branch: "master",
  },
  {
    id: 212595520,
    node_id: "MDEwOlJlcG9zaXRvcnkyMTI1OTU1MjA=",
    name: "gatsby-personal-site-2019-starter",
    full_name: "john-smilga/gatsby-personal-site-2019-starter",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/gatsby-personal-site-2019-starter",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-personal-site-2019-starter/deployments",
    created_at: "2019-10-03T14:04:22Z",
    updated_at: "2020-03-12T14:50:48Z",
    pushed_at: "2019-10-03T14:05:41Z",
    git_url:
      "git://github.com/john-smilga/gatsby-personal-site-2019-starter.git",
    ssh_url: "git@github.com:john-smilga/gatsby-personal-site-2019-starter.git",
    clone_url:
      "https://github.com/john-smilga/gatsby-personal-site-2019-starter.git",
    svn_url: "https://github.com/john-smilga/gatsby-personal-site-2019-starter",
    homepage: null,
    size: 343,
    stargazers_count: 9,
    watchers_count: 9,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 6,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 6,
    open_issues: 0,
    watchers: 9,
    default_branch: "master",
  },
  {
    id: 163125355,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjMxMjUzNTU=",
    name: "gatsby-real-estate-project",
    full_name: "john-smilga/gatsby-real-estate-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-real-estate-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-real-estate-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-real-estate-project/deployments",
    created_at: "2018-12-26T02:05:38Z",
    updated_at: "2020-04-24T18:18:25Z",
    pushed_at: "2018-12-28T06:39:17Z",
    git_url: "git://github.com/john-smilga/gatsby-real-estate-project.git",
    ssh_url: "git@github.com:john-smilga/gatsby-real-estate-project.git",
    clone_url: "https://github.com/john-smilga/gatsby-real-estate-project.git",
    svn_url: "https://github.com/john-smilga/gatsby-real-estate-project",
    homepage: null,
    size: 1556,
    stargazers_count: 6,
    watchers_count: 6,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 1,
    open_issues: 0,
    watchers: 6,
    default_branch: "master",
  },
  {
    id: 163077461,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjMwNzc0NjE=",
    name: "gatsby-restaurant-project",
    full_name: "john-smilga/gatsby-restaurant-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-restaurant-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-restaurant-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-restaurant-project/deployments",
    created_at: "2018-12-25T11:39:14Z",
    updated_at: "2020-06-14T18:54:04Z",
    pushed_at: "2020-04-06T15:34:53Z",
    git_url: "git://github.com/john-smilga/gatsby-restaurant-project.git",
    ssh_url: "git@github.com:john-smilga/gatsby-restaurant-project.git",
    clone_url: "https://github.com/john-smilga/gatsby-restaurant-project.git",
    svn_url: "https://github.com/john-smilga/gatsby-restaurant-project",
    homepage: null,
    size: 1312,
    stargazers_count: 3,
    watchers_count: 3,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 6,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 1,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 6,
    open_issues: 1,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 194372845,
    node_id: "MDEwOlJlcG9zaXRvcnkxOTQzNzI4NDU=",
    name: "gatsby-second-tutorial-recording",
    full_name: "john-smilga/gatsby-second-tutorial-recording",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-second-tutorial-recording",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-second-tutorial-recording/deployments",
    created_at: "2019-06-29T06:31:11Z",
    updated_at: "2019-10-11T18:20:55Z",
    pushed_at: "2019-06-29T07:07:42Z",
    git_url:
      "git://github.com/john-smilga/gatsby-second-tutorial-recording.git",
    ssh_url: "git@github.com:john-smilga/gatsby-second-tutorial-recording.git",
    clone_url:
      "https://github.com/john-smilga/gatsby-second-tutorial-recording.git",
    svn_url: "https://github.com/john-smilga/gatsby-second-tutorial-recording",
    homepage: null,
    size: 3331,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 163073449,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjMwNzM0NDk=",
    name: "gatsby-starter-project",
    full_name: "john-smilga/gatsby-starter-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-starter-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-starter-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-starter-project/deployments",
    created_at: "2018-12-25T10:38:02Z",
    updated_at: "2019-10-11T18:17:34Z",
    pushed_at: "2018-12-29T05:22:07Z",
    git_url: "git://github.com/john-smilga/gatsby-starter-project.git",
    ssh_url: "git@github.com:john-smilga/gatsby-starter-project.git",
    clone_url: "https://github.com/john-smilga/gatsby-starter-project.git",
    svn_url: "https://github.com/john-smilga/gatsby-starter-project",
    homepage: null,
    size: 1193,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 161992582,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjE5OTI1ODI=",
    name: "gatsby-store",
    full_name: "john-smilga/gatsby-store",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-store",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-store",
    forks_url: "https://api.github.com/repos/john-smilga/gatsby-store/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/gatsby-store/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/gatsby-store/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/issues/events{/number}",
    events_url: "https://api.github.com/repos/john-smilga/gatsby-store/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/gatsby-store/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/compare/{base}...{head}",
    merges_url: "https://api.github.com/repos/john-smilga/gatsby-store/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-store/deployments",
    created_at: "2018-12-16T11:04:08Z",
    updated_at: "2019-10-11T18:17:40Z",
    pushed_at: "2018-12-16T11:10:03Z",
    git_url: "git://github.com/john-smilga/gatsby-store.git",
    ssh_url: "git@github.com:john-smilga/gatsby-store.git",
    clone_url: "https://github.com/john-smilga/gatsby-store.git",
    svn_url: "https://github.com/john-smilga/gatsby-store",
    homepage: null,
    size: 342,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 264540330,
    node_id: "MDEwOlJlcG9zaXRvcnkyNjQ1NDAzMzA=",
    name: "gatsby-strapi-portfolio-site-2020",
    full_name: "john-smilga/gatsby-strapi-portfolio-site-2020",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/gatsby-strapi-portfolio-site-2020",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-strapi-portfolio-site-2020/deployments",
    created_at: "2020-05-16T22:36:51Z",
    updated_at: "2020-06-24T00:50:07Z",
    pushed_at: "2020-06-05T16:08:11Z",
    git_url:
      "git://github.com/john-smilga/gatsby-strapi-portfolio-site-2020.git",
    ssh_url: "git@github.com:john-smilga/gatsby-strapi-portfolio-site-2020.git",
    clone_url:
      "https://github.com/john-smilga/gatsby-strapi-portfolio-site-2020.git",
    svn_url: "https://github.com/john-smilga/gatsby-strapi-portfolio-site-2020",
    homepage: null,
    size: 7462,
    stargazers_count: 13,
    watchers_count: 13,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 16,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 16,
    open_issues: 0,
    watchers: 13,
    default_branch: "master",
  },
  {
    id: 249115665,
    node_id: "MDEwOlJlcG9zaXRvcnkyNDkxMTU2NjU=",
    name: "gatsby-tutorial-2020",
    full_name: "john-smilga/gatsby-tutorial-2020",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-tutorial-2020",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-2020/deployments",
    created_at: "2020-03-22T04:53:10Z",
    updated_at: "2020-06-20T17:44:52Z",
    pushed_at: "2020-04-03T02:03:48Z",
    git_url: "git://github.com/john-smilga/gatsby-tutorial-2020.git",
    ssh_url: "git@github.com:john-smilga/gatsby-tutorial-2020.git",
    clone_url: "https://github.com/john-smilga/gatsby-tutorial-2020.git",
    svn_url: "https://github.com/john-smilga/gatsby-tutorial-2020",
    homepage: null,
    size: 19292,
    stargazers_count: 10,
    watchers_count: 10,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 9,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 9,
    open_issues: 0,
    watchers: 10,
    default_branch: "master",
  },
  {
    id: 220380466,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjAzODA0NjY=",
    name: "gatsby-tutorial-project",
    full_name: "john-smilga/gatsby-tutorial-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gatsby-tutorial-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gatsby-tutorial-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gatsby-tutorial-project/deployments",
    created_at: "2019-11-08T03:37:17Z",
    updated_at: "2019-12-12T20:59:40Z",
    pushed_at: "2019-11-08T05:11:42Z",
    git_url: "git://github.com/john-smilga/gatsby-tutorial-project.git",
    ssh_url: "git@github.com:john-smilga/gatsby-tutorial-project.git",
    clone_url: "https://github.com/john-smilga/gatsby-tutorial-project.git",
    svn_url: "https://github.com/john-smilga/gatsby-tutorial-project",
    homepage: null,
    size: 3330,
    stargazers_count: 2,
    watchers_count: 2,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 161138625,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjExMzg2MjU=",
    name: "grid-coffee-project-final",
    full_name: "john-smilga/grid-coffee-project-final",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/grid-coffee-project-final",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/grid-coffee-project-final",
    forks_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/grid-coffee-project-final/deployments",
    created_at: "2018-12-10T07:59:54Z",
    updated_at: "2020-02-29T15:07:49Z",
    pushed_at: "2018-12-10T08:00:49Z",
    git_url: "git://github.com/john-smilga/grid-coffee-project-final.git",
    ssh_url: "git@github.com:john-smilga/grid-coffee-project-final.git",
    clone_url: "https://github.com/john-smilga/grid-coffee-project-final.git",
    svn_url: "https://github.com/john-smilga/grid-coffee-project-final",
    homepage: null,
    size: 24290,
    stargazers_count: 6,
    watchers_count: 6,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 6,
    default_branch: "master",
  },
  {
    id: 199532549,
    node_id: "MDEwOlJlcG9zaXRvcnkxOTk1MzI1NDk=",
    name: "grid-mini-projects",
    full_name: "john-smilga/grid-mini-projects",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/grid-mini-projects",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/grid-mini-projects",
    forks_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/grid-mini-projects/deployments",
    created_at: "2019-07-29T22:04:56Z",
    updated_at: "2020-06-16T12:20:15Z",
    pushed_at: "2019-07-29T22:11:33Z",
    git_url: "git://github.com/john-smilga/grid-mini-projects.git",
    ssh_url: "git@github.com:john-smilga/grid-mini-projects.git",
    clone_url: "https://github.com/john-smilga/grid-mini-projects.git",
    svn_url: "https://github.com/john-smilga/grid-mini-projects",
    homepage: null,
    size: 3616,
    stargazers_count: 5,
    watchers_count: 5,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 154205941,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTQyMDU5NDE=",
    name: "gulp-css",
    full_name: "john-smilga/gulp-css",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/gulp-css",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/gulp-css",
    forks_url: "https://api.github.com/repos/john-smilga/gulp-css/forks",
    keys_url: "https://api.github.com/repos/john-smilga/gulp-css/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/gulp-css/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/gulp-css/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/gulp-css/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/gulp-css/issues/events{/number}",
    events_url: "https://api.github.com/repos/john-smilga/gulp-css/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/gulp-css/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/gulp-css/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/gulp-css/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/gulp-css/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/gulp-css/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/gulp-css/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/gulp-css/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/gulp-css/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/gulp-css/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/gulp-css/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/gulp-css/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/gulp-css/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/gulp-css/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/gulp-css/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/gulp-css/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/gulp-css/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/gulp-css/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/gulp-css/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/gulp-css/compare/{base}...{head}",
    merges_url: "https://api.github.com/repos/john-smilga/gulp-css/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/gulp-css/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/gulp-css/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/gulp-css/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/gulp-css/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/gulp-css/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/gulp-css/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/gulp-css/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/gulp-css/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/gulp-css/deployments",
    created_at: "2018-10-22T19:44:22Z",
    updated_at: "2019-10-11T18:19:03Z",
    pushed_at: "2018-10-22T19:44:46Z",
    git_url: "git://github.com/john-smilga/gulp-css.git",
    ssh_url: "git@github.com:john-smilga/gulp-css.git",
    clone_url: "https://github.com/john-smilga/gulp-css.git",
    svn_url: "https://github.com/john-smilga/gulp-css",
    homepage: null,
    size: 25,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 172117285,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzIxMTcyODU=",
    name: "html-css-fast-and-faster-car-project",
    full_name: "john-smilga/html-css-fast-and-faster-car-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/html-css-fast-and-faster-car-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-fast-and-faster-car-project/deployments",
    created_at: "2019-02-22T18:42:14Z",
    updated_at: "2020-06-10T17:40:48Z",
    pushed_at: "2019-02-22T18:42:40Z",
    git_url:
      "git://github.com/john-smilga/html-css-fast-and-faster-car-project.git",
    ssh_url:
      "git@github.com:john-smilga/html-css-fast-and-faster-car-project.git",
    clone_url:
      "https://github.com/john-smilga/html-css-fast-and-faster-car-project.git",
    svn_url:
      "https://github.com/john-smilga/html-css-fast-and-faster-car-project",
    homepage: null,
    size: 1074,
    stargazers_count: 4,
    watchers_count: 4,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 4,
    default_branch: "master",
  },
  {
    id: 246083508,
    node_id: "MDEwOlJlcG9zaXRvcnkyNDYwODM1MDg=",
    name: "html-css-flexbox-backroads-new-design-2020",
    full_name: "john-smilga/html-css-flexbox-backroads-new-design-2020",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/html-css-flexbox-backroads-new-design-2020",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-flexbox-backroads-new-design-2020/deployments",
    created_at: "2020-03-09T16:14:53Z",
    updated_at: "2020-05-01T11:12:51Z",
    pushed_at: "2020-03-11T17:37:19Z",
    git_url:
      "git://github.com/john-smilga/html-css-flexbox-backroads-new-design-2020.git",
    ssh_url:
      "git@github.com:john-smilga/html-css-flexbox-backroads-new-design-2020.git",
    clone_url:
      "https://github.com/john-smilga/html-css-flexbox-backroads-new-design-2020.git",
    svn_url:
      "https://github.com/john-smilga/html-css-flexbox-backroads-new-design-2020",
    homepage: null,
    size: 3774,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 253897372,
    node_id: "MDEwOlJlcG9zaXRvcnkyNTM4OTczNzI=",
    name: "html-css-grid-project-recording",
    full_name: "john-smilga/html-css-grid-project-recording",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/html-css-grid-project-recording",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-grid-project-recording/deployments",
    created_at: "2020-04-07T19:53:03Z",
    updated_at: "2020-06-16T12:16:49Z",
    pushed_at: "2020-04-11T02:25:59Z",
    git_url: "git://github.com/john-smilga/html-css-grid-project-recording.git",
    ssh_url: "git@github.com:john-smilga/html-css-grid-project-recording.git",
    clone_url:
      "https://github.com/john-smilga/html-css-grid-project-recording.git",
    svn_url: "https://github.com/john-smilga/html-css-grid-project-recording",
    homepage: null,
    size: 23097,
    stargazers_count: 15,
    watchers_count: 15,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 6,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 6,
    open_issues: 0,
    watchers: 15,
    default_branch: "master",
  },
  {
    id: 172316136,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzIzMTYxMzY=",
    name: "html-css-only-floats-tea-station-project",
    full_name: "john-smilga/html-css-only-floats-tea-station-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/html-css-only-floats-tea-station-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-only-floats-tea-station-project/deployments",
    created_at: "2019-02-24T08:56:19Z",
    updated_at: "2020-06-14T04:06:43Z",
    pushed_at: "2019-03-04T01:27:41Z",
    git_url:
      "git://github.com/john-smilga/html-css-only-floats-tea-station-project.git",
    ssh_url:
      "git@github.com:john-smilga/html-css-only-floats-tea-station-project.git",
    clone_url:
      "https://github.com/john-smilga/html-css-only-floats-tea-station-project.git",
    svn_url:
      "https://github.com/john-smilga/html-css-only-floats-tea-station-project",
    homepage: null,
    size: 3372,
    stargazers_count: 6,
    watchers_count: 6,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 6,
    default_branch: "master",
  },
  {
    id: 253330529,
    node_id: "MDEwOlJlcG9zaXRvcnkyNTMzMzA1Mjk=",
    name: "html-css-portfolio-project-with-css-grid",
    full_name: "john-smilga/html-css-portfolio-project-with-css-grid",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/html-css-portfolio-project-with-css-grid",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-portfolio-project-with-css-grid/deployments",
    created_at: "2020-04-05T20:56:27Z",
    updated_at: "2020-05-22T01:00:42Z",
    pushed_at: "2020-04-10T23:39:05Z",
    git_url:
      "git://github.com/john-smilga/html-css-portfolio-project-with-css-grid.git",
    ssh_url:
      "git@github.com:john-smilga/html-css-portfolio-project-with-css-grid.git",
    clone_url:
      "https://github.com/john-smilga/html-css-portfolio-project-with-css-grid.git",
    svn_url:
      "https://github.com/john-smilga/html-css-portfolio-project-with-css-grid",
    homepage: null,
    size: 23073,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 243644470,
    node_id: "MDEwOlJlcG9zaXRvcnkyNDM2NDQ0NzA=",
    name: "html-css-tea-station-new-design",
    full_name: "john-smilga/html-css-tea-station-new-design",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/html-css-tea-station-new-design",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-tea-station-new-design/deployments",
    created_at: "2020-02-28T00:22:51Z",
    updated_at: "2020-06-02T14:29:21Z",
    pushed_at: "2020-05-28T03:39:41Z",
    git_url: "git://github.com/john-smilga/html-css-tea-station-new-design.git",
    ssh_url: "git@github.com:john-smilga/html-css-tea-station-new-design.git",
    clone_url:
      "https://github.com/john-smilga/html-css-tea-station-new-design.git",
    svn_url: "https://github.com/john-smilga/html-css-tea-station-new-design",
    homepage: null,
    size: 3519,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 243642117,
    node_id: "MDEwOlJlcG9zaXRvcnkyNDM2NDIxMTc=",
    name: "html-css-tutorial-source-code",
    full_name: "john-smilga/html-css-tutorial-source-code",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/html-css-tutorial-source-code",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code",
    forks_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/html-css-tutorial-source-code/deployments",
    created_at: "2020-02-28T00:04:15Z",
    updated_at: "2020-06-14T04:02:06Z",
    pushed_at: "2020-02-28T00:05:26Z",
    git_url: "git://github.com/john-smilga/html-css-tutorial-source-code.git",
    ssh_url: "git@github.com:john-smilga/html-css-tutorial-source-code.git",
    clone_url:
      "https://github.com/john-smilga/html-css-tutorial-source-code.git",
    svn_url: "https://github.com/john-smilga/html-css-tutorial-source-code",
    homepage: null,
    size: 16694,
    stargazers_count: 2,
    watchers_count: 2,
    language: null,
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 222361926,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjIzNjE5MjY=",
    name: "javascript-basic-projects",
    full_name: "john-smilga/javascript-basic-projects",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/javascript-basic-projects",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/javascript-basic-projects",
    forks_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/javascript-basic-projects/deployments",
    created_at: "2019-11-18T04:13:41Z",
    updated_at: "2020-06-24T13:34:15Z",
    pushed_at: "2020-06-14T21:59:33Z",
    git_url: "git://github.com/john-smilga/javascript-basic-projects.git",
    ssh_url: "git@github.com:john-smilga/javascript-basic-projects.git",
    clone_url: "https://github.com/john-smilga/javascript-basic-projects.git",
    svn_url: "https://github.com/john-smilga/javascript-basic-projects",
    homepage: null,
    size: 9962,
    stargazers_count: 206,
    watchers_count: 206,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 198,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 1,
    license: null,
    forks: 198,
    open_issues: 1,
    watchers: 206,
    default_branch: "master",
  },
  {
    id: 272515104,
    node_id: "MDEwOlJlcG9zaXRvcnkyNzI1MTUxMDQ=",
    name: "javascript-tutorial-source-code",
    full_name: "john-smilga/javascript-tutorial-source-code",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/javascript-tutorial-source-code",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code",
    forks_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/javascript-tutorial-source-code/deployments",
    created_at: "2020-06-15T18:31:14Z",
    updated_at: "2020-06-23T20:19:44Z",
    pushed_at: "2020-06-23T20:19:42Z",
    git_url: "git://github.com/john-smilga/javascript-tutorial-source-code.git",
    ssh_url: "git@github.com:john-smilga/javascript-tutorial-source-code.git",
    clone_url:
      "https://github.com/john-smilga/javascript-tutorial-source-code.git",
    svn_url: "https://github.com/john-smilga/javascript-tutorial-source-code",
    homepage: null,
    size: 204,
    stargazers_count: 2,
    watchers_count: 2,
    language: null,
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 147059133,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDcwNTkxMzM=",
    name: "js-backgroundImage-setup",
    full_name: "john-smilga/js-backgroundImage-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-backgroundImage-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-backgroundImage-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-backgroundImage-setup/deployments",
    created_at: "2018-09-02T06:04:07Z",
    updated_at: "2019-10-11T18:19:44Z",
    pushed_at: "2018-09-02T06:04:30Z",
    git_url: "git://github.com/john-smilga/js-backgroundImage-setup.git",
    ssh_url: "git@github.com:john-smilga/js-backgroundImage-setup.git",
    clone_url: "https://github.com/john-smilga/js-backgroundImage-setup.git",
    svn_url: "https://github.com/john-smilga/js-backgroundImage-setup",
    homepage: null,
    size: 1584,
    stargazers_count: 3,
    watchers_count: 3,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 3,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 3,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 201061178,
    node_id: "MDEwOlJlcG9zaXRvcnkyMDEwNjExNzg=",
    name: "js-budget-calculator-project",
    full_name: "john-smilga/js-budget-calculator-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-budget-calculator-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-budget-calculator-project/deployments",
    created_at: "2019-08-07T13:56:59Z",
    updated_at: "2019-10-11T18:20:38Z",
    pushed_at: "2019-08-07T13:57:51Z",
    git_url: "git://github.com/john-smilga/js-budget-calculator-project.git",
    ssh_url: "git@github.com:john-smilga/js-budget-calculator-project.git",
    clone_url:
      "https://github.com/john-smilga/js-budget-calculator-project.git",
    svn_url: "https://github.com/john-smilga/js-budget-calculator-project",
    homepage: null,
    size: 1600,
    stargazers_count: 4,
    watchers_count: 4,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 4,
    default_branch: "master",
  },
  {
    id: 148002294,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDgwMDIyOTQ=",
    name: "js-budget-setup",
    full_name: "john-smilga/js-budget-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-budget-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-budget-setup",
    forks_url: "https://api.github.com/repos/john-smilga/js-budget-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/js-budget-setup/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/js-budget-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-budget-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-budget-setup/deployments",
    created_at: "2018-09-09T07:20:17Z",
    updated_at: "2020-06-02T22:48:38Z",
    pushed_at: "2018-09-16T22:50:08Z",
    git_url: "git://github.com/john-smilga/js-budget-setup.git",
    ssh_url: "git@github.com:john-smilga/js-budget-setup.git",
    clone_url: "https://github.com/john-smilga/js-budget-setup.git",
    svn_url: "https://github.com/john-smilga/js-budget-setup",
    homepage: null,
    size: 1601,
    stargazers_count: 59,
    watchers_count: 59,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 118,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 2,
    license: null,
    forks: 118,
    open_issues: 2,
    watchers: 59,
    default_branch: "master",
  },
  {
    id: 147757273,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDc3NTcyNzM=",
    name: "js-calculator-setup",
    full_name: "john-smilga/js-calculator-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-calculator-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-calculator-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-calculator-setup/deployments",
    created_at: "2018-09-07T02:04:41Z",
    updated_at: "2019-10-11T18:19:25Z",
    pushed_at: "2018-09-07T02:05:29Z",
    git_url: "git://github.com/john-smilga/js-calculator-setup.git",
    ssh_url: "git@github.com:john-smilga/js-calculator-setup.git",
    clone_url: "https://github.com/john-smilga/js-calculator-setup.git",
    svn_url: "https://github.com/john-smilga/js-calculator-setup",
    homepage: null,
    size: 1,
    stargazers_count: 3,
    watchers_count: 3,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 147252793,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDcyNTI3OTM=",
    name: "js-cart-setup",
    full_name: "john-smilga/js-cart-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-cart-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-cart-setup",
    forks_url: "https://api.github.com/repos/john-smilga/js-cart-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/js-cart-setup/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/js-cart-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/issues/events{/number}",
    events_url: "https://api.github.com/repos/john-smilga/js-cart-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-cart-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/compare/{base}...{head}",
    merges_url: "https://api.github.com/repos/john-smilga/js-cart-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-cart-setup/deployments",
    created_at: "2018-09-03T20:55:30Z",
    updated_at: "2020-06-10T17:40:57Z",
    pushed_at: "2019-01-09T05:20:01Z",
    git_url: "git://github.com/john-smilga/js-cart-setup.git",
    ssh_url: "git@github.com:john-smilga/js-cart-setup.git",
    clone_url: "https://github.com/john-smilga/js-cart-setup.git",
    svn_url: "https://github.com/john-smilga/js-cart-setup",
    homepage: null,
    size: 1872,
    stargazers_count: 59,
    watchers_count: 59,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 112,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 1,
    license: null,
    forks: 112,
    open_issues: 1,
    watchers: 59,
    default_branch: "master",
  },
  {
    id: 177690513,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzc2OTA1MTM=",
    name: "js-challanges",
    full_name: "john-smilga/js-challanges",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-challanges",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-challanges",
    forks_url: "https://api.github.com/repos/john-smilga/js-challanges/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-challanges/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-challanges/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/js-challanges/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/js-challanges/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-challanges/issues/events{/number}",
    events_url: "https://api.github.com/repos/john-smilga/js-challanges/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-challanges/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-challanges/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-challanges/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-challanges/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-challanges/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-challanges/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-challanges/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-challanges/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-challanges/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-challanges/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-challanges/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-challanges/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-challanges/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-challanges/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-challanges/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-challanges/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-challanges/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-challanges/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-challanges/compare/{base}...{head}",
    merges_url: "https://api.github.com/repos/john-smilga/js-challanges/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-challanges/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-challanges/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-challanges/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-challanges/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-challanges/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-challanges/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-challanges/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-challanges/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-challanges/deployments",
    created_at: "2019-03-26T01:13:11Z",
    updated_at: "2020-06-10T17:40:35Z",
    pushed_at: "2019-03-31T04:57:43Z",
    git_url: "git://github.com/john-smilga/js-challanges.git",
    ssh_url: "git@github.com:john-smilga/js-challanges.git",
    clone_url: "https://github.com/john-smilga/js-challanges.git",
    svn_url: "https://github.com/john-smilga/js-challanges",
    homepage: null,
    size: 4,
    stargazers_count: 2,
    watchers_count: 2,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 146057357,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDYwNTczNTc=",
    name: "js-changeBackground-setup",
    full_name: "john-smilga/js-changeBackground-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-changeBackground-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-changeBackground-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-changeBackground-setup/deployments",
    created_at: "2018-08-25T02:18:04Z",
    updated_at: "2019-10-11T18:19:55Z",
    pushed_at: "2018-08-25T02:19:31Z",
    git_url: "git://github.com/john-smilga/js-changeBackground-setup.git",
    ssh_url: "git@github.com:john-smilga/js-changeBackground-setup.git",
    clone_url: "https://github.com/john-smilga/js-changeBackground-setup.git",
    svn_url: "https://github.com/john-smilga/js-changeBackground-setup",
    homepage: null,
    size: 410,
    stargazers_count: 3,
    watchers_count: 3,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 177386706,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzczODY3MDY=",
    name: "js-comfy-house-furniture-store",
    full_name: "john-smilga/js-comfy-house-furniture-store",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-comfy-house-furniture-store",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-furniture-store/deployments",
    created_at: "2019-03-24T08:06:01Z",
    updated_at: "2020-03-14T08:12:44Z",
    pushed_at: "2019-03-24T08:06:25Z",
    git_url: "git://github.com/john-smilga/js-comfy-house-furniture-store.git",
    ssh_url: "git@github.com:john-smilga/js-comfy-house-furniture-store.git",
    clone_url:
      "https://github.com/john-smilga/js-comfy-house-furniture-store.git",
    svn_url: "https://github.com/john-smilga/js-comfy-house-furniture-store",
    homepage: null,
    size: 827,
    stargazers_count: 5,
    watchers_count: 5,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 7,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 7,
    open_issues: 0,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 188646865,
    node_id: "MDEwOlJlcG9zaXRvcnkxODg2NDY4NjU=",
    name: "js-comfy-house-parcel-setup",
    full_name: "john-smilga/js-comfy-house-parcel-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-comfy-house-parcel-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-comfy-house-parcel-setup/deployments",
    created_at: "2019-05-26T06:10:53Z",
    updated_at: "2020-02-20T09:24:53Z",
    pushed_at: "2020-04-05T13:04:39Z",
    git_url: "git://github.com/john-smilga/js-comfy-house-parcel-setup.git",
    ssh_url: "git@github.com:john-smilga/js-comfy-house-parcel-setup.git",
    clone_url: "https://github.com/john-smilga/js-comfy-house-parcel-setup.git",
    svn_url: "https://github.com/john-smilga/js-comfy-house-parcel-setup",
    homepage: null,
    size: 1042,
    stargazers_count: 6,
    watchers_count: 6,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 2,
    license: null,
    forks: 2,
    open_issues: 2,
    watchers: 6,
    default_branch: "master",
  },
  {
    id: 146977354,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDY5NzczNTQ=",
    name: "js-counter-setup",
    full_name: "john-smilga/js-counter-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-counter-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-counter-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-counter-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-counter-setup/deployments",
    created_at: "2018-09-01T07:21:12Z",
    updated_at: "2019-10-11T18:19:45Z",
    pushed_at: "2018-09-01T07:21:36Z",
    git_url: "git://github.com/john-smilga/js-counter-setup.git",
    ssh_url: "git@github.com:john-smilga/js-counter-setup.git",
    clone_url: "https://github.com/john-smilga/js-counter-setup.git",
    svn_url: "https://github.com/john-smilga/js-counter-setup",
    homepage: null,
    size: 679,
    stargazers_count: 1,
    watchers_count: 1,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 148384526,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDgzODQ1MjY=",
    name: "js-course-form-setup",
    full_name: "john-smilga/js-course-form-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-course-form-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-course-form-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-course-form-setup/deployments",
    created_at: "2018-09-11T21:49:34Z",
    updated_at: "2019-10-11T18:19:18Z",
    pushed_at: "2018-09-11T21:50:59Z",
    git_url: "git://github.com/john-smilga/js-course-form-setup.git",
    ssh_url: "git@github.com:john-smilga/js-course-form-setup.git",
    clone_url: "https://github.com/john-smilga/js-course-form-setup.git",
    svn_url: "https://github.com/john-smilga/js-course-form-setup",
    homepage: null,
    size: 1996,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 146856060,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDY4NTYwNjA=",
    name: "js-displayQuotes-setup",
    full_name: "john-smilga/js-displayQuotes-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-displayQuotes-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-displayQuotes-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-displayQuotes-setup/deployments",
    created_at: "2018-08-31T07:14:40Z",
    updated_at: "2019-10-11T18:19:49Z",
    pushed_at: "2018-08-31T07:15:06Z",
    git_url: "git://github.com/john-smilga/js-displayQuotes-setup.git",
    ssh_url: "git@github.com:john-smilga/js-displayQuotes-setup.git",
    clone_url: "https://github.com/john-smilga/js-displayQuotes-setup.git",
    svn_url: "https://github.com/john-smilga/js-displayQuotes-setup",
    homepage: null,
    size: 613,
    stargazers_count: 2,
    watchers_count: 2,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 147119397,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDcxMTkzOTc=",
    name: "js-filter-setup",
    full_name: "john-smilga/js-filter-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-filter-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-filter-setup",
    forks_url: "https://api.github.com/repos/john-smilga/js-filter-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/js-filter-setup/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/js-filter-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-filter-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-filter-setup/deployments",
    created_at: "2018-09-02T20:29:28Z",
    updated_at: "2019-10-11T18:19:42Z",
    pushed_at: "2018-09-02T20:29:50Z",
    git_url: "git://github.com/john-smilga/js-filter-setup.git",
    ssh_url: "git@github.com:john-smilga/js-filter-setup.git",
    clone_url: "https://github.com/john-smilga/js-filter-setup.git",
    svn_url: "https://github.com/john-smilga/js-filter-setup",
    homepage: null,
    size: 1855,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 147912698,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDc5MTI2OTg=",
    name: "js-flashcards-setup",
    full_name: "john-smilga/js-flashcards-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-flashcards-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-flashcards-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-flashcards-setup/deployments",
    created_at: "2018-09-08T07:40:32Z",
    updated_at: "2019-10-11T18:19:25Z",
    pushed_at: "2018-09-08T07:41:10Z",
    git_url: "git://github.com/john-smilga/js-flashcards-setup.git",
    ssh_url: "git@github.com:john-smilga/js-flashcards-setup.git",
    clone_url: "https://github.com/john-smilga/js-flashcards-setup.git",
    svn_url: "https://github.com/john-smilga/js-flashcards-setup",
    homepage: null,
    size: 1599,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 151166269,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTExNjYyNjk=",
    name: "js-githubAPI-setup",
    full_name: "john-smilga/js-githubAPI-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-githubAPI-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-githubAPI-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-githubAPI-setup/deployments",
    created_at: "2018-10-01T21:57:36Z",
    updated_at: "2019-10-11T18:19:09Z",
    pushed_at: "2018-10-01T21:59:02Z",
    git_url: "git://github.com/john-smilga/js-githubAPI-setup.git",
    ssh_url: "git@github.com:john-smilga/js-githubAPI-setup.git",
    clone_url: "https://github.com/john-smilga/js-githubAPI-setup.git",
    svn_url: "https://github.com/john-smilga/js-githubAPI-setup",
    homepage: null,
    size: 1625,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 147745595,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDc3NDU1OTU=",
    name: "js-grocery-list-setup",
    full_name: "john-smilga/js-grocery-list-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-grocery-list-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-grocery-list-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-grocery-list-setup/deployments",
    created_at: "2018-09-06T23:39:45Z",
    updated_at: "2019-10-11T18:19:26Z",
    pushed_at: "2018-09-06T23:43:57Z",
    git_url: "git://github.com/john-smilga/js-grocery-list-setup.git",
    ssh_url: "git@github.com:john-smilga/js-grocery-list-setup.git",
    clone_url: "https://github.com/john-smilga/js-grocery-list-setup.git",
    svn_url: "https://github.com/john-smilga/js-grocery-list-setup",
    homepage: null,
    size: 1524,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 146190001,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDYxOTAwMDE=",
    name: "js-hexColor-setup",
    full_name: "john-smilga/js-hexColor-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-hexColor-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-hexColor-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-hexColor-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-hexColor-setup/deployments",
    created_at: "2018-08-26T14:55:36Z",
    updated_at: "2019-10-11T18:19:51Z",
    pushed_at: "2018-08-26T14:58:23Z",
    git_url: "git://github.com/john-smilga/js-hexColor-setup.git",
    ssh_url: "git@github.com:john-smilga/js-hexColor-setup.git",
    clone_url: "https://github.com/john-smilga/js-hexColor-setup.git",
    svn_url: "https://github.com/john-smilga/js-hexColor-setup",
    homepage: null,
    size: 411,
    stargazers_count: 1,
    watchers_count: 1,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 150653033,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTA2NTMwMzM=",
    name: "js-httpMethods-setup",
    full_name: "john-smilga/js-httpMethods-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-httpMethods-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-httpMethods-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-httpMethods-setup/deployments",
    created_at: "2018-09-27T22:02:42Z",
    updated_at: "2019-10-11T18:19:11Z",
    pushed_at: "2018-09-27T22:03:16Z",
    git_url: "git://github.com/john-smilga/js-httpMethods-setup.git",
    ssh_url: "git@github.com:john-smilga/js-httpMethods-setup.git",
    clone_url: "https://github.com/john-smilga/js-httpMethods-setup.git",
    svn_url: "https://github.com/john-smilga/js-httpMethods-setup",
    homepage: null,
    size: 1178,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 150498749,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTA0OTg3NDk=",
    name: "js-jokes-setup",
    full_name: "john-smilga/js-jokes-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-jokes-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-jokes-setup",
    forks_url: "https://api.github.com/repos/john-smilga/js-jokes-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/js-jokes-setup/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/js-jokes-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-jokes-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-jokes-setup/deployments",
    created_at: "2018-09-26T22:47:33Z",
    updated_at: "2019-10-11T18:19:15Z",
    pushed_at: "2018-09-26T22:49:01Z",
    git_url: "git://github.com/john-smilga/js-jokes-setup.git",
    ssh_url: "git@github.com:john-smilga/js-jokes-setup.git",
    clone_url: "https://github.com/john-smilga/js-jokes-setup.git",
    svn_url: "https://github.com/john-smilga/js-jokes-setup",
    homepage: null,
    size: 1524,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 147119001,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDcxMTkwMDE=",
    name: "js-modal-setup",
    full_name: "john-smilga/js-modal-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-modal-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-modal-setup",
    forks_url: "https://api.github.com/repos/john-smilga/js-modal-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/js-modal-setup/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/js-modal-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-modal-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-modal-setup/deployments",
    created_at: "2018-09-02T20:23:20Z",
    updated_at: "2019-10-11T18:19:44Z",
    pushed_at: "2018-09-02T20:27:58Z",
    git_url: "git://github.com/john-smilga/js-modal-setup.git",
    ssh_url: "git@github.com:john-smilga/js-modal-setup.git",
    clone_url: "https://github.com/john-smilga/js-modal-setup.git",
    svn_url: "https://github.com/john-smilga/js-modal-setup",
    homepage: null,
    size: 1855,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 146713944,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDY3MTM5NDQ=",
    name: "js-passMessage-setup",
    full_name: "john-smilga/js-passMessage-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-passMessage-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-passMessage-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-passMessage-setup/deployments",
    created_at: "2018-08-30T07:40:56Z",
    updated_at: "2019-10-11T18:19:49Z",
    pushed_at: "2018-08-30T07:41:20Z",
    git_url: "git://github.com/john-smilga/js-passMessage-setup.git",
    ssh_url: "git@github.com:john-smilga/js-passMessage-setup.git",
    clone_url: "https://github.com/john-smilga/js-passMessage-setup.git",
    svn_url: "https://github.com/john-smilga/js-passMessage-setup",
    homepage: null,
    size: 612,
    stargazers_count: 2,
    watchers_count: 2,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 150503189,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTA1MDMxODk=",
    name: "js-randomPersonAPI-setup",
    full_name: "john-smilga/js-randomPersonAPI-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-randomPersonAPI-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-randomPersonAPI-setup/deployments",
    created_at: "2018-09-26T23:50:07Z",
    updated_at: "2019-10-11T18:19:15Z",
    pushed_at: "2018-09-26T23:51:02Z",
    git_url: "git://github.com/john-smilga/js-randomPersonAPI-setup.git",
    ssh_url: "git@github.com:john-smilga/js-randomPersonAPI-setup.git",
    clone_url: "https://github.com/john-smilga/js-randomPersonAPI-setup.git",
    svn_url: "https://github.com/john-smilga/js-randomPersonAPI-setup",
    homepage: null,
    size: 1560,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 202580967,
    node_id: "MDEwOlJlcG9zaXRvcnkyMDI1ODA5Njc=",
    name: "js-simple-calculator",
    full_name: "john-smilga/js-simple-calculator",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-simple-calculator",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-simple-calculator",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-simple-calculator/deployments",
    created_at: "2019-08-15T17:06:38Z",
    updated_at: "2020-06-10T17:40:30Z",
    pushed_at: "2019-08-15T17:06:53Z",
    git_url: "git://github.com/john-smilga/js-simple-calculator.git",
    ssh_url: "git@github.com:john-smilga/js-simple-calculator.git",
    clone_url: "https://github.com/john-smilga/js-simple-calculator.git",
    svn_url: "https://github.com/john-smilga/js-simple-calculator",
    homepage: null,
    size: 1,
    stargazers_count: 3,
    watchers_count: 3,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 207137292,
    node_id: "MDEwOlJlcG9zaXRvcnkyMDcxMzcyOTI=",
    name: "js-slider-project",
    full_name: "john-smilga/js-slider-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-slider-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-slider-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-slider-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-slider-project/deployments",
    created_at: "2019-09-08T16:02:08Z",
    updated_at: "2020-06-10T17:40:23Z",
    pushed_at: "2019-09-08T16:02:56Z",
    git_url: "git://github.com/john-smilga/js-slider-project.git",
    ssh_url: "git@github.com:john-smilga/js-slider-project.git",
    clone_url: "https://github.com/john-smilga/js-slider-project.git",
    svn_url: "https://github.com/john-smilga/js-slider-project",
    homepage: null,
    size: 3420,
    stargazers_count: 3,
    watchers_count: 3,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 146258942,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDYyNTg5NDI=",
    name: "js-testimonials-setup",
    full_name: "john-smilga/js-testimonials-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-testimonials-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-testimonials-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-testimonials-setup/deployments",
    created_at: "2018-08-27T06:58:49Z",
    updated_at: "2019-10-11T18:19:50Z",
    pushed_at: "2018-08-27T06:59:08Z",
    git_url: "git://github.com/john-smilga/js-testimonials-setup.git",
    ssh_url: "git@github.com:john-smilga/js-testimonials-setup.git",
    clone_url: "https://github.com/john-smilga/js-testimonials-setup.git",
    svn_url: "https://github.com/john-smilga/js-testimonials-setup",
    homepage: null,
    size: 980,
    stargazers_count: 1,
    watchers_count: 1,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 147297955,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDcyOTc5NTU=",
    name: "js-tip-calculator-setup",
    full_name: "john-smilga/js-tip-calculator-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-tip-calculator-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-tip-calculator-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-tip-calculator-setup/deployments",
    created_at: "2018-09-04T06:25:02Z",
    updated_at: "2019-10-11T18:19:27Z",
    pushed_at: "2018-09-04T06:26:15Z",
    git_url: "git://github.com/john-smilga/js-tip-calculator-setup.git",
    ssh_url: "git@github.com:john-smilga/js-tip-calculator-setup.git",
    clone_url: "https://github.com/john-smilga/js-tip-calculator-setup.git",
    svn_url: "https://github.com/john-smilga/js-tip-calculator-setup",
    homepage: null,
    size: 1524,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 149015653,
    node_id: "MDEwOlJlcG9zaXRvcnkxNDkwMTU2NTM=",
    name: "js-toDoList-setup",
    full_name: "john-smilga/js-toDoList-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-toDoList-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-toDoList-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-toDoList-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-toDoList-setup/deployments",
    created_at: "2018-09-16T16:48:36Z",
    updated_at: "2019-10-11T18:19:17Z",
    pushed_at: "2018-09-16T16:50:00Z",
    git_url: "git://github.com/john-smilga/js-toDoList-setup.git",
    ssh_url: "git@github.com:john-smilga/js-toDoList-setup.git",
    clone_url: "https://github.com/john-smilga/js-toDoList-setup.git",
    svn_url: "https://github.com/john-smilga/js-toDoList-setup",
    homepage: null,
    size: 1524,
    stargazers_count: 4,
    watchers_count: 4,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 6,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 6,
    open_issues: 0,
    watchers: 4,
    default_branch: "master",
  },
  {
    id: 226408720,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjY0MDg3MjA=",
    name: "js-tutorial-recording",
    full_name: "john-smilga/js-tutorial-recording",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-tutorial-recording",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-tutorial-recording",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-tutorial-recording/deployments",
    created_at: "2019-12-06T20:53:17Z",
    updated_at: "2020-01-13T18:58:05Z",
    pushed_at: "2020-01-13T18:58:03Z",
    git_url: "git://github.com/john-smilga/js-tutorial-recording.git",
    ssh_url: "git@github.com:john-smilga/js-tutorial-recording.git",
    clone_url: "https://github.com/john-smilga/js-tutorial-recording.git",
    svn_url: "https://github.com/john-smilga/js-tutorial-recording",
    homepage: null,
    size: 20,
    stargazers_count: 0,
    watchers_count: 0,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 0,
    default_branch: "master",
  },
  {
    id: 151165567,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTExNjU1Njc=",
    name: "js-wheatherAPI-setup",
    full_name: "john-smilga/js-wheatherAPI-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-wheatherAPI-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-wheatherAPI-setup/deployments",
    created_at: "2018-10-01T21:49:50Z",
    updated_at: "2019-10-11T18:19:10Z",
    pushed_at: "2018-10-01T21:50:31Z",
    git_url: "git://github.com/john-smilga/js-wheatherAPI-setup.git",
    ssh_url: "git@github.com:john-smilga/js-wheatherAPI-setup.git",
    clone_url: "https://github.com/john-smilga/js-wheatherAPI-setup.git",
    svn_url: "https://github.com/john-smilga/js-wheatherAPI-setup",
    homepage: null,
    size: 1240,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 150507608,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTA1MDc2MDg=",
    name: "js-wikiAPI-setup",
    full_name: "john-smilga/js-wikiAPI-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-wikiAPI-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-wikiAPI-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-wikiAPI-setup/deployments",
    created_at: "2018-09-27T00:49:24Z",
    updated_at: "2019-10-11T18:19:12Z",
    pushed_at: "2018-09-27T00:51:33Z",
    git_url: "git://github.com/john-smilga/js-wikiAPI-setup.git",
    ssh_url: "git@github.com:john-smilga/js-wikiAPI-setup.git",
    clone_url: "https://github.com/john-smilga/js-wikiAPI-setup.git",
    svn_url: "https://github.com/john-smilga/js-wikiAPI-setup",
    homepage: null,
    size: 1261,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 160071640,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjAwNzE2NDA=",
    name: "js-zomato-restaurant-app",
    full_name: "john-smilga/js-zomato-restaurant-app",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-zomato-restaurant-app",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-zomato-restaurant-app/deployments",
    created_at: "2018-12-02T17:23:21Z",
    updated_at: "2020-06-10T17:41:05Z",
    pushed_at: "2018-12-02T17:28:19Z",
    git_url: "git://github.com/john-smilga/js-zomato-restaurant-app.git",
    ssh_url: "git@github.com:john-smilga/js-zomato-restaurant-app.git",
    clone_url: "https://github.com/john-smilga/js-zomato-restaurant-app.git",
    svn_url: "https://github.com/john-smilga/js-zomato-restaurant-app",
    homepage: null,
    size: 1383,
    stargazers_count: 3,
    watchers_count: 3,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
  {
    id: 160072260,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjAwNzIyNjA=",
    name: "js-zomatoAPI-setup",
    full_name: "john-smilga/js-zomatoAPI-setup",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/js-zomatoAPI-setup",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup",
    forks_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/js-zomatoAPI-setup/deployments",
    created_at: "2018-12-02T17:31:21Z",
    updated_at: "2019-10-11T18:18:41Z",
    pushed_at: "2018-12-02T17:32:44Z",
    git_url: "git://github.com/john-smilga/js-zomatoAPI-setup.git",
    ssh_url: "git@github.com:john-smilga/js-zomatoAPI-setup.git",
    clone_url: "https://github.com/john-smilga/js-zomatoAPI-setup.git",
    svn_url: "https://github.com/john-smilga/js-zomatoAPI-setup",
    homepage: null,
    size: 1220,
    stargazers_count: 2,
    watchers_count: 2,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 165978031,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjU5NzgwMzE=",
    name: "node-basics-project",
    full_name: "john-smilga/node-basics-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/node-basics-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/node-basics-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/node-basics-project/deployments",
    created_at: "2019-01-16T05:13:50Z",
    updated_at: "2019-10-11T18:17:24Z",
    pushed_at: "2019-01-16T05:14:13Z",
    git_url: "git://github.com/john-smilga/node-basics-project.git",
    ssh_url: "git@github.com:john-smilga/node-basics-project.git",
    clone_url: "https://github.com/john-smilga/node-basics-project.git",
    svn_url: "https://github.com/john-smilga/node-basics-project",
    homepage: null,
    size: 34,
    stargazers_count: 4,
    watchers_count: 4,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 4,
    default_branch: "master",
  },
  {
    id: 165807752,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjU4MDc3NTI=",
    name: "node-setup-project",
    full_name: "john-smilga/node-setup-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/node-setup-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/node-setup-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/node-setup-project/deployments",
    created_at: "2019-01-15T07:47:03Z",
    updated_at: "2019-10-11T18:17:25Z",
    pushed_at: "2019-01-15T07:47:36Z",
    git_url: "git://github.com/john-smilga/node-setup-project.git",
    ssh_url: "git@github.com:john-smilga/node-setup-project.git",
    clone_url: "https://github.com/john-smilga/node-setup-project.git",
    svn_url: "https://github.com/john-smilga/node-setup-project",
    homepage: null,
    size: 31,
    stargazers_count: 2,
    watchers_count: 2,
    language: "HTML",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 230308384,
    node_id: "MDEwOlJlcG9zaXRvcnkyMzAzMDgzODQ=",
    name: "question-udemy-gatsby",
    full_name: "john-smilga/question-udemy-gatsby",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/question-udemy-gatsby",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/question-udemy-gatsby",
    forks_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby/deployments",
    created_at: "2019-12-26T18:14:24Z",
    updated_at: "2020-01-04T14:37:11Z",
    pushed_at: "2019-12-26T18:15:14Z",
    git_url: "git://github.com/john-smilga/question-udemy-gatsby.git",
    ssh_url: "git@github.com:john-smilga/question-udemy-gatsby.git",
    clone_url: "https://github.com/john-smilga/question-udemy-gatsby.git",
    svn_url: "https://github.com/john-smilga/question-udemy-gatsby",
    homepage: null,
    size: 364,
    stargazers_count: 1,
    watchers_count: 1,
    language: "CSS",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 256863696,
    node_id: "MDEwOlJlcG9zaXRvcnkyNTY4NjM2OTY=",
    name: "question-udemy-gatsby-course",
    full_name: "john-smilga/question-udemy-gatsby-course",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/question-udemy-gatsby-course",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course",
    forks_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/question-udemy-gatsby-course/deployments",
    created_at: "2020-04-18T22:16:50Z",
    updated_at: "2020-04-18T22:17:49Z",
    pushed_at: "2020-04-18T22:17:46Z",
    git_url: "git://github.com/john-smilga/question-udemy-gatsby-course.git",
    ssh_url: "git@github.com:john-smilga/question-udemy-gatsby-course.git",
    clone_url:
      "https://github.com/john-smilga/question-udemy-gatsby-course.git",
    svn_url: "https://github.com/john-smilga/question-udemy-gatsby-course",
    homepage: null,
    size: 517,
    stargazers_count: 0,
    watchers_count: 0,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 0,
    default_branch: "master",
  },
  {
    id: 163498913,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjM0OTg5MTM=",
    name: "random-stuff",
    full_name: "john-smilga/random-stuff",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/random-stuff",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/random-stuff",
    forks_url: "https://api.github.com/repos/john-smilga/random-stuff/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/random-stuff/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/random-stuff/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/random-stuff/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/random-stuff/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/random-stuff/issues/events{/number}",
    events_url: "https://api.github.com/repos/john-smilga/random-stuff/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/random-stuff/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/random-stuff/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/random-stuff/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/random-stuff/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/random-stuff/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/random-stuff/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/random-stuff/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/random-stuff/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/random-stuff/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/random-stuff/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/random-stuff/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/random-stuff/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/random-stuff/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/random-stuff/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/random-stuff/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/random-stuff/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/random-stuff/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/random-stuff/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/random-stuff/compare/{base}...{head}",
    merges_url: "https://api.github.com/repos/john-smilga/random-stuff/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/random-stuff/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/random-stuff/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/random-stuff/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/random-stuff/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/random-stuff/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/random-stuff/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/random-stuff/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/random-stuff/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/random-stuff/deployments",
    created_at: "2018-12-29T09:43:06Z",
    updated_at: "2019-10-11T18:17:34Z",
    pushed_at: "2018-12-29T09:44:25Z",
    git_url: "git://github.com/john-smilga/random-stuff.git",
    ssh_url: "git@github.com:john-smilga/random-stuff.git",
    clone_url: "https://github.com/john-smilga/random-stuff.git",
    svn_url: "https://github.com/john-smilga/random-stuff",
    homepage: null,
    size: 1018,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: {
      key: "mit",
      name: "MIT License",
      spdx_id: "MIT",
      url: "https://api.github.com/licenses/mit",
      node_id: "MDc6TGljZW5zZTEz",
    },
    forks: 0,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 183956267,
    node_id: "MDEwOlJlcG9zaXRvcnkxODM5NTYyNjc=",
    name: "react-beach-resort-project",
    full_name: "john-smilga/react-beach-resort-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-beach-resort-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-beach-resort-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-beach-resort-project/deployments",
    created_at: "2019-04-28T20:36:32Z",
    updated_at: "2020-06-22T07:51:45Z",
    pushed_at: "2020-06-06T15:29:37Z",
    git_url: "git://github.com/john-smilga/react-beach-resort-project.git",
    ssh_url: "git@github.com:john-smilga/react-beach-resort-project.git",
    clone_url: "https://github.com/john-smilga/react-beach-resort-project.git",
    svn_url: "https://github.com/john-smilga/react-beach-resort-project",
    homepage: null,
    size: 2321,
    stargazers_count: 127,
    watchers_count: 127,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 117,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 11,
    license: null,
    forks: 117,
    open_issues: 11,
    watchers: 127,
    default_branch: "master",
  },
  {
    id: 173629467,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzM2Mjk0Njc=",
    name: "react-city-tours-project",
    full_name: "john-smilga/react-city-tours-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-city-tours-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-city-tours-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-city-tours-project/deployments",
    created_at: "2019-03-03T21:02:11Z",
    updated_at: "2020-02-26T07:42:22Z",
    pushed_at: "2019-03-04T00:42:43Z",
    git_url: "git://github.com/john-smilga/react-city-tours-project.git",
    ssh_url: "git@github.com:john-smilga/react-city-tours-project.git",
    clone_url: "https://github.com/john-smilga/react-city-tours-project.git",
    svn_url: "https://github.com/john-smilga/react-city-tours-project",
    homepage: null,
    size: 822,
    stargazers_count: 8,
    watchers_count: 8,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 8,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 8,
    open_issues: 0,
    watchers: 8,
    default_branch: "master",
  },
  {
    id: 226434002,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjY0MzQwMDI=",
    name: "react-cocktailsdb-project",
    full_name: "john-smilga/react-cocktailsdb-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-cocktailsdb-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-cocktailsdb-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-cocktailsdb-project/deployments",
    created_at: "2019-12-07T00:39:14Z",
    updated_at: "2020-06-13T16:41:14Z",
    pushed_at: "2019-12-11T18:10:48Z",
    git_url: "git://github.com/john-smilga/react-cocktailsdb-project.git",
    ssh_url: "git@github.com:john-smilga/react-cocktailsdb-project.git",
    clone_url: "https://github.com/john-smilga/react-cocktailsdb-project.git",
    svn_url: "https://github.com/john-smilga/react-cocktailsdb-project",
    homepage: null,
    size: 186,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 222995108,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjI5OTUxMDg=",
    name: "react-e-commerce-v2",
    full_name: "john-smilga/react-e-commerce-v2",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-e-commerce-v2",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-e-commerce-v2",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-e-commerce-v2/deployments",
    created_at: "2019-11-20T17:49:19Z",
    updated_at: "2020-03-10T17:24:07Z",
    pushed_at: "2019-11-25T22:25:11Z",
    git_url: "git://github.com/john-smilga/react-e-commerce-v2.git",
    ssh_url: "git@github.com:john-smilga/react-e-commerce-v2.git",
    clone_url: "https://github.com/john-smilga/react-e-commerce-v2.git",
    svn_url: "https://github.com/john-smilga/react-e-commerce-v2",
    homepage: null,
    size: 402,
    stargazers_count: 4,
    watchers_count: 4,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 5,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 5,
    open_issues: 0,
    watchers: 4,
    default_branch: "master",
  },
  {
    id: 156128287,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTYxMjgyODc=",
    name: "react-fourth-project-hotel-room-search",
    full_name: "john-smilga/react-fourth-project-hotel-room-search",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/react-fourth-project-hotel-room-search",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-fourth-project-hotel-room-search/deployments",
    created_at: "2018-11-04T21:46:49Z",
    updated_at: "2019-10-11T18:18:57Z",
    pushed_at: "2018-11-06T07:16:17Z",
    git_url:
      "git://github.com/john-smilga/react-fourth-project-hotel-room-search.git",
    ssh_url:
      "git@github.com:john-smilga/react-fourth-project-hotel-room-search.git",
    clone_url:
      "https://github.com/john-smilga/react-fourth-project-hotel-room-search.git",
    svn_url:
      "https://github.com/john-smilga/react-fourth-project-hotel-room-search",
    homepage: null,
    size: 150,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 1,
    license: null,
    forks: 2,
    open_issues: 1,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 195668566,
    node_id: "MDEwOlJlcG9zaXRvcnkxOTU2Njg1NjY=",
    name: "react-hooks-budged-calculator-app",
    full_name: "john-smilga/react-hooks-budged-calculator-app",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/react-hooks-budged-calculator-app",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-hooks-budged-calculator-app/deployments",
    created_at: "2019-07-07T15:39:05Z",
    updated_at: "2020-06-22T16:49:13Z",
    pushed_at: "2020-06-07T00:25:00Z",
    git_url:
      "git://github.com/john-smilga/react-hooks-budged-calculator-app.git",
    ssh_url: "git@github.com:john-smilga/react-hooks-budged-calculator-app.git",
    clone_url:
      "https://github.com/john-smilga/react-hooks-budged-calculator-app.git",
    svn_url: "https://github.com/john-smilga/react-hooks-budged-calculator-app",
    homepage: null,
    size: 736,
    stargazers_count: 17,
    watchers_count: 17,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 16,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 4,
    license: null,
    forks: 16,
    open_issues: 4,
    watchers: 17,
    default_branch: "master",
  },
  {
    id: 174274657,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzQyNzQ2NTc=",
    name: "react-luxury-hotel",
    full_name: "john-smilga/react-luxury-hotel",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-luxury-hotel",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-luxury-hotel",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-luxury-hotel/deployments",
    created_at: "2019-03-07T04:59:47Z",
    updated_at: "2020-06-10T17:40:38Z",
    pushed_at: "2019-03-07T20:51:00Z",
    git_url: "git://github.com/john-smilga/react-luxury-hotel.git",
    ssh_url: "git@github.com:john-smilga/react-luxury-hotel.git",
    clone_url: "https://github.com/john-smilga/react-luxury-hotel.git",
    svn_url: "https://github.com/john-smilga/react-luxury-hotel",
    homepage: null,
    size: 626,
    stargazers_count: 5,
    watchers_count: 5,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 5,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 5,
    open_issues: 0,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 155118414,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTUxMTg0MTQ=",
    name: "react-person-list-project",
    full_name: "john-smilga/react-person-list-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-person-list-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-person-list-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-person-list-project/deployments",
    created_at: "2018-10-28T21:40:45Z",
    updated_at: "2020-06-10T17:40:50Z",
    pushed_at: "2019-03-02T06:23:34Z",
    git_url: "git://github.com/john-smilga/react-person-list-project.git",
    ssh_url: "git@github.com:john-smilga/react-person-list-project.git",
    clone_url: "https://github.com/john-smilga/react-person-list-project.git",
    svn_url: "https://github.com/john-smilga/react-person-list-project",
    homepage: null,
    size: 200,
    stargazers_count: 6,
    watchers_count: 6,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 4,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 4,
    open_issues: 0,
    watchers: 6,
    default_branch: "master",
  },
  {
    id: 162105335,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjIxMDUzMzU=",
    name: "react-phone-e-commerce-project",
    full_name: "john-smilga/react-phone-e-commerce-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-phone-e-commerce-project",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-phone-e-commerce-project/deployments",
    created_at: "2018-12-17T09:23:03Z",
    updated_at: "2020-06-17T15:06:30Z",
    pushed_at: "2019-02-02T19:48:49Z",
    git_url: "git://github.com/john-smilga/react-phone-e-commerce-project.git",
    ssh_url: "git@github.com:john-smilga/react-phone-e-commerce-project.git",
    clone_url:
      "https://github.com/john-smilga/react-phone-e-commerce-project.git",
    svn_url: "https://github.com/john-smilga/react-phone-e-commerce-project",
    homepage: null,
    size: 429,
    stargazers_count: 79,
    watchers_count: 79,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 69,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 3,
    license: null,
    forks: 69,
    open_issues: 3,
    watchers: 79,
    default_branch: "master",
  },
  {
    id: 156788630,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTY3ODg2MzA=",
    name: "react-project5-portfolio",
    full_name: "john-smilga/react-project5-portfolio",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-project5-portfolio",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-project5-portfolio",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-project5-portfolio/deployments",
    created_at: "2018-11-09T00:48:02Z",
    updated_at: "2019-10-11T18:18:55Z",
    pushed_at: "2018-11-09T01:03:28Z",
    git_url: "git://github.com/john-smilga/react-project5-portfolio.git",
    ssh_url: "git@github.com:john-smilga/react-project5-portfolio.git",
    clone_url: "https://github.com/john-smilga/react-project5-portfolio.git",
    svn_url: "https://github.com/john-smilga/react-project5-portfolio",
    homepage: null,
    size: 2076,
    stargazers_count: 2,
    watchers_count: 2,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 2,
    default_branch: "master",
  },
  {
    id: 180413259,
    node_id: "MDEwOlJlcG9zaXRvcnkxODA0MTMyNTk=",
    name: "react-question",
    full_name: "john-smilga/react-question",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-question",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-question",
    forks_url: "https://api.github.com/repos/john-smilga/react-question/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-question/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-question/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/react-question/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/react-question/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-question/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-question/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-question/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-question/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/react-question/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-question/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-question/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-question/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-question/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-question/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-question/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-question/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-question/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-question/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-question/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-question/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-question/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-question/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-question/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-question/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-question/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-question/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-question/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-question/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-question/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-question/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-question/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-question/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-question/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-question/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-question/deployments",
    created_at: "2019-04-09T17:01:35Z",
    updated_at: "2019-10-11T18:21:11Z",
    pushed_at: "2019-04-09T17:02:05Z",
    git_url: "git://github.com/john-smilga/react-question.git",
    ssh_url: "git@github.com:john-smilga/react-question.git",
    clone_url: "https://github.com/john-smilga/react-question.git",
    svn_url: "https://github.com/john-smilga/react-question",
    homepage: null,
    size: 180,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 161304622,
    node_id: "MDEwOlJlcG9zaXRvcnkxNjEzMDQ2MjI=",
    name: "react-recipe-search-project",
    full_name: "john-smilga/react-recipe-search-project",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-recipe-search-project",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-recipe-search-project",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-recipe-search-project/deployments",
    created_at: "2018-12-11T08:49:33Z",
    updated_at: "2020-04-28T21:15:41Z",
    pushed_at: "2018-12-29T19:59:28Z",
    git_url: "git://github.com/john-smilga/react-recipe-search-project.git",
    ssh_url: "git@github.com:john-smilga/react-recipe-search-project.git",
    clone_url: "https://github.com/john-smilga/react-recipe-search-project.git",
    svn_url: "https://github.com/john-smilga/react-recipe-search-project",
    homepage: null,
    size: 147,
    stargazers_count: 7,
    watchers_count: 7,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 10,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 1,
    license: null,
    forks: 10,
    open_issues: 1,
    watchers: 7,
    default_branch: "master",
  },
  {
    id: 174760535,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzQ3NjA1MzU=",
    name: "react-revised-recipe-application",
    full_name: "john-smilga/react-revised-recipe-application",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-revised-recipe-application",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-revised-recipe-application/deployments",
    created_at: "2019-03-10T00:19:57Z",
    updated_at: "2019-12-12T21:02:45Z",
    pushed_at: "2019-03-10T00:20:44Z",
    git_url:
      "git://github.com/john-smilga/react-revised-recipe-application.git",
    ssh_url: "git@github.com:john-smilga/react-revised-recipe-application.git",
    clone_url:
      "https://github.com/john-smilga/react-revised-recipe-application.git",
    svn_url: "https://github.com/john-smilga/react-revised-recipe-application",
    homepage: null,
    size: 409,
    stargazers_count: 4,
    watchers_count: 4,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 2,
    open_issues: 0,
    watchers: 4,
    default_branch: "master",
  },
  {
    id: 175172785,
    node_id: "MDEwOlJlcG9zaXRvcnkxNzUxNzI3ODU=",
    name: "react-tech-store",
    full_name: "john-smilga/react-tech-store",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-tech-store",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-tech-store",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/react-tech-store/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-tech-store/deployments",
    created_at: "2019-03-12T09:01:26Z",
    updated_at: "2020-06-13T16:41:32Z",
    pushed_at: "2019-03-30T04:24:55Z",
    git_url: "git://github.com/john-smilga/react-tech-store.git",
    ssh_url: "git@github.com:john-smilga/react-tech-store.git",
    clone_url: "https://github.com/john-smilga/react-tech-store.git",
    svn_url: "https://github.com/john-smilga/react-tech-store",
    homepage: null,
    size: 2423,
    stargazers_count: 5,
    watchers_count: 5,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 8,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 8,
    open_issues: 0,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 155667062,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTU2NjcwNjI=",
    name: "react-third-project-todo-list",
    full_name: "john-smilga/react-third-project-todo-list",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-third-project-todo-list",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-third-project-todo-list/deployments",
    created_at: "2018-11-01T05:40:43Z",
    updated_at: "2019-10-11T18:19:01Z",
    pushed_at: "2018-11-01T05:48:40Z",
    git_url: "git://github.com/john-smilga/react-third-project-todo-list.git",
    ssh_url: "git@github.com:john-smilga/react-third-project-todo-list.git",
    clone_url:
      "https://github.com/john-smilga/react-third-project-todo-list.git",
    svn_url: "https://github.com/john-smilga/react-third-project-todo-list",
    homepage: null,
    size: 139,
    stargazers_count: 1,
    watchers_count: 1,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 1,
    default_branch: "master",
  },
  {
    id: 249043725,
    node_id: "MDEwOlJlcG9zaXRvcnkyNDkwNDM3MjU=",
    name: "react-timestamp-app",
    full_name: "john-smilga/react-timestamp-app",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-timestamp-app",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-timestamp-app",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-timestamp-app/deployments",
    created_at: "2020-03-21T19:13:18Z",
    updated_at: "2020-05-02T19:19:04Z",
    pushed_at: "2020-05-02T19:19:02Z",
    git_url: "git://github.com/john-smilga/react-timestamp-app.git",
    ssh_url: "git@github.com:john-smilga/react-timestamp-app.git",
    clone_url: "https://github.com/john-smilga/react-timestamp-app.git",
    svn_url: "https://github.com/john-smilga/react-timestamp-app",
    homepage: null,
    size: 175,
    stargazers_count: 0,
    watchers_count: 0,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 1,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 1,
    open_issues: 0,
    watchers: 0,
    default_branch: "master",
  },
  {
    id: 159910841,
    node_id: "MDEwOlJlcG9zaXRvcnkxNTk5MTA4NDE=",
    name: "react-todo-list",
    full_name: "john-smilga/react-todo-list",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/react-todo-list",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/react-todo-list",
    forks_url: "https://api.github.com/repos/john-smilga/react-todo-list/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/collaborators{/collaborator}",
    teams_url: "https://api.github.com/repos/john-smilga/react-todo-list/teams",
    hooks_url: "https://api.github.com/repos/john-smilga/react-todo-list/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/branches{/branch}",
    tags_url: "https://api.github.com/repos/john-smilga/react-todo-list/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-todo-list/deployments",
    created_at: "2018-12-01T05:03:13Z",
    updated_at: "2020-06-02T09:17:44Z",
    pushed_at: "2018-12-01T05:04:03Z",
    git_url: "git://github.com/john-smilga/react-todo-list.git",
    ssh_url: "git@github.com:john-smilga/react-todo-list.git",
    clone_url: "https://github.com/john-smilga/react-todo-list.git",
    svn_url: "https://github.com/john-smilga/react-todo-list",
    homepage: null,
    size: 139,
    stargazers_count: 5,
    watchers_count: 5,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 2,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 1,
    license: null,
    forks: 2,
    open_issues: 1,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 231141168,
    node_id: "MDEwOlJlcG9zaXRvcnkyMzExNDExNjg=",
    name: "react-udemy-vintage-tech-extra-fetures",
    full_name: "john-smilga/react-udemy-vintage-tech-extra-fetures",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url:
      "https://github.com/john-smilga/react-udemy-vintage-tech-extra-fetures",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures",
    forks_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/react-udemy-vintage-tech-extra-fetures/deployments",
    created_at: "2019-12-31T20:01:26Z",
    updated_at: "2020-06-16T12:23:40Z",
    pushed_at: "2020-02-04T20:22:10Z",
    git_url:
      "git://github.com/john-smilga/react-udemy-vintage-tech-extra-fetures.git",
    ssh_url:
      "git@github.com:john-smilga/react-udemy-vintage-tech-extra-fetures.git",
    clone_url:
      "https://github.com/john-smilga/react-udemy-vintage-tech-extra-fetures.git",
    svn_url:
      "https://github.com/john-smilga/react-udemy-vintage-tech-extra-fetures",
    homepage: null,
    size: 292,
    stargazers_count: 5,
    watchers_count: 5,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 4,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 4,
    open_issues: 0,
    watchers: 5,
    default_branch: "master",
  },
  {
    id: 247773549,
    node_id: "MDEwOlJlcG9zaXRvcnkyNDc3NzM1NDk=",
    name: "redux-tutorial-cart",
    full_name: "john-smilga/redux-tutorial-cart",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/redux-tutorial-cart",
    description: null,
    fork: false,
    url: "https://api.github.com/repos/john-smilga/redux-tutorial-cart",
    forks_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-cart/deployments",
    created_at: "2020-03-16T17:10:35Z",
    updated_at: "2020-06-14T04:03:03Z",
    pushed_at: "2020-03-19T03:43:05Z",
    git_url: "git://github.com/john-smilga/redux-tutorial-cart.git",
    ssh_url: "git@github.com:john-smilga/redux-tutorial-cart.git",
    clone_url: "https://github.com/john-smilga/redux-tutorial-cart.git",
    svn_url: "https://github.com/john-smilga/redux-tutorial-cart",
    homepage: null,
    size: 194,
    stargazers_count: 11,
    watchers_count: 11,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 4,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 4,
    open_issues: 0,
    watchers: 11,
    default_branch: "master",
  },
  {
    id: 229477702,
    node_id: "MDEwOlJlcG9zaXRvcnkyMjk0Nzc3MDI=",
    name: "redux-tutorial-simple-counter",
    full_name: "john-smilga/redux-tutorial-simple-counter",
    private: false,
    owner: {
      login: "john-smilga",
      id: 42133389,
      node_id: "MDQ6VXNlcjQyMTMzMzg5",
      avatar_url: "https://avatars3.githubusercontent.com/u/42133389?v=4",
      gravatar_id: "",
      url: "https://api.github.com/users/john-smilga",
      html_url: "https://github.com/john-smilga",
      followers_url: "https://api.github.com/users/john-smilga/followers",
      following_url:
        "https://api.github.com/users/john-smilga/following{/other_user}",
      gists_url: "https://api.github.com/users/john-smilga/gists{/gist_id}",
      starred_url:
        "https://api.github.com/users/john-smilga/starred{/owner}{/repo}",
      subscriptions_url:
        "https://api.github.com/users/john-smilga/subscriptions",
      organizations_url: "https://api.github.com/users/john-smilga/orgs",
      repos_url: "https://api.github.com/users/john-smilga/repos",
      events_url: "https://api.github.com/users/john-smilga/events{/privacy}",
      received_events_url:
        "https://api.github.com/users/john-smilga/received_events",
      type: "User",
      site_admin: false,
    },
    html_url: "https://github.com/john-smilga/redux-tutorial-simple-counter",
    description: null,
    fork: false,
    url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter",
    forks_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/forks",
    keys_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/keys{/key_id}",
    collaborators_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/collaborators{/collaborator}",
    teams_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/teams",
    hooks_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/hooks",
    issue_events_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/issues/events{/number}",
    events_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/events",
    assignees_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/assignees{/user}",
    branches_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/branches{/branch}",
    tags_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/tags",
    blobs_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/git/blobs{/sha}",
    git_tags_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/git/tags{/sha}",
    git_refs_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/git/refs{/sha}",
    trees_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/git/trees{/sha}",
    statuses_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/statuses/{sha}",
    languages_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/languages",
    stargazers_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/stargazers",
    contributors_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/contributors",
    subscribers_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/subscribers",
    subscription_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/subscription",
    commits_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/commits{/sha}",
    git_commits_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/git/commits{/sha}",
    comments_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/comments{/number}",
    issue_comment_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/issues/comments{/number}",
    contents_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/contents/{+path}",
    compare_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/compare/{base}...{head}",
    merges_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/merges",
    archive_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/{archive_format}{/ref}",
    downloads_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/downloads",
    issues_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/issues{/number}",
    pulls_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/pulls{/number}",
    milestones_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/milestones{/number}",
    notifications_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/notifications{?since,all,participating}",
    labels_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/labels{/name}",
    releases_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/releases{/id}",
    deployments_url:
      "https://api.github.com/repos/john-smilga/redux-tutorial-simple-counter/deployments",
    created_at: "2019-12-21T20:09:08Z",
    updated_at: "2020-06-13T16:41:36Z",
    pushed_at: "2019-12-24T00:29:25Z",
    git_url: "git://github.com/john-smilga/redux-tutorial-simple-counter.git",
    ssh_url: "git@github.com:john-smilga/redux-tutorial-simple-counter.git",
    clone_url:
      "https://github.com/john-smilga/redux-tutorial-simple-counter.git",
    svn_url: "https://github.com/john-smilga/redux-tutorial-simple-counter",
    homepage: null,
    size: 192,
    stargazers_count: 3,
    watchers_count: 3,
    language: "JavaScript",
    has_issues: true,
    has_projects: true,
    has_downloads: true,
    has_wiki: true,
    has_pages: false,
    forks_count: 0,
    mirror_url: null,
    archived: false,
    disabled: false,
    open_issues_count: 0,
    license: null,
    forks: 0,
    open_issues: 0,
    watchers: 3,
    default_branch: "master",
  },
];
